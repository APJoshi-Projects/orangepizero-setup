#!/bin/sh
echo `shutdown -h now`
