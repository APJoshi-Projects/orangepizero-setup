#!/bin/sh
// Create a user agent so websites don't block you
$userAgent = 'Googlebot/2.1 (http://www.google.bot.com/bot.html)';

// Create the initial link you want.
$target_url = "http://192.168.225.85/Web/index.php";

// Initialize curl and following options
$ch = curl_init();
curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
curl_setopt($ch, CURLOPT_URL,$target_url);
curl_setopt($ch, CURLOPT_FAILONERROR, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_AUTOREFERER, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);


// Grab the html from the page
$html = curl_exec($ch);

// Error handling
if(!$html){
     handle error if page was not reachable, etc
     exit();
}


// Create a new DOM Document to handle scraping
$dom = new DOMDocument();
@$dom->loadHTML($html);


// get your element, you can do this numerous ways like getting by tag, id or using a DOMXPath object
// This example gets elements with id forward-link which might be a div or ul or li, etc
// It then gets all the a tags (links) within all those divs, uls, etc
// Then it takes the first link in the array of links and then grabs the href from the link
$search = $dom->getElementById('forward-link');
$forwardlink = $search->getElementById('button_7');
$forwardlink = $forwardlink->item(0);
$forwardlink = $getNamedItem('href');
$href = $forwardlink->textContent;


// Now that you have the link you want to follow/click to
// Set the target_url for the cUrl to the new url
curl_setopt($ch, CURLOPT_URL, $target_url);

$html = curl_exec($ch);


// do what you want with your new link!

